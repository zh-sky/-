

class Node(object):
    """节点"""
    def __init__(self, val):
        self.val = val
        self.next = None


class SingleLinkList(object):
    """单向循环链表"""
    def __init__(self, node=None):
        self.__head = node
        if node != None:
            node.next = node

    def is_empty(self):
        """链表是否为空"""
        return self.__head == None

    def length(self):
        """返回链表的长度"""
        cur = self.__head
        if self.is_empty():
            return 0
        count = 1
        while cur.next != self.__head:
            count += 1
            cur = cur.next
        return count

    def travel(self):
        """遍历整个链表"""
        if self.is_empty():
            return
        cur = self.__head
        while cur.next != self.__head:
            print(cur.val)
            cur = cur.next
        print(cur.val)

    def add(self, item):
        """链表头部添加元素"""
        node = Node(item)
        if self.is_empty():
            node.next = self.__head
            self.__head = node
        else:
            cur = self.__head
            if cur.next != self.__head:
                cur = cur.next
            node.next = self.__head
            self.__head = node
            cur.next = self.__head

    def append(self, item):
        """链表尾部添加元素"""
        node = Node(item)
        if self.is_empty():
            self.__head = node
        else:
            cur = self.__head
            while cur.next != self.__head:
                cur = cur.next
            cur.next = node
        node.next = self.__head

    def insert(self, pos, item):
        """指定位置插入元素
        :param pos (从0开始)
        """
        if pos < 0:
            pos = 0
        elif pos > self.length() - 1:
            pos = self.length() - 1
        node = Node(item)
        index = 0
        pre = self.__head
        while index < pos - 1:
            index += 1
            pre = pre.next
        node.next = pre.next
        pre.next = node

    def remove(self, item):
        """删除节点"""
        if self.is_empty():
            return
        pre = None
        cur = self.__head
        while cur != self.__head:
            if cur.val == item:
                if cur == self.__head:
                    rear = self.__head
                    while rear.next != self.__head:
                        rear = rear.next
                    self.__head = cur.next
                    rear.next = self.__head
                else:
                    pre.next = cur.next
                break
            else:
                pre = cur
                cur = cur.next
        # 1.退出循环指向尾节点 2.列表中只要一个节点
        if cur.val == item and self.length() == 1:
            self.__head = None
        else:
            pre.next = cur.next

    def search(self, item):
        """查找节点"""
        if self.is_empty():
            return False
        cur = self.__head
        while cur != self.__head:
            if cur.val == item:
                return True
            cur = cur.next
        # 退出循环  指向尾节点
        if cur.val == item:
            return True
        else:
            return False


if __name__ == "__main__":
    sll = SingleLinkList()
    print(sll.is_empty())
    print(sll.length())

    sll.append(1)
    sll.add(2)
    sll.add(3)
    sll.insert(1, 8)
    # print(sll.length())
    sll.travel()