# """
# 创建：
# info = {
#     "k1":18,
#     2:True,
#     "k4":(11, 22,)
# }
#
# 删除
# del info["k1"]
#
# 打印key
# for item in info:
#     print(item)
# """
# # 根据序列创建字典，并指定统一的值
# v = dict.fromkeys(["k1", '123', '999'], 123)
# print(v)
#
# # 通过get取值，如果该key不存在，默认返回为None,可以指定默认值。不会报错，如果用索引取值会报错
# print(v.get('k11'))
#
# del_num = v.pop('k1')
# print(v, del_num)
#
# # 设置值
# # 已存在，不设置，获取当前key对应的值
# # 不存在，设置值，获取当前key对应的值
# v.setdefault('k2', 666)
# print(v)


import time
li1 = [1, 2]
li2 = [3, 4]
li3 = li1 + li2
li = [i for i in range(1000)]
li4 = []
for i in range(1000):
    li4.append(i)
li5 = list[range(1000)]

def test1():
    li = []
    for i in range(1000):
        li.append(i)
