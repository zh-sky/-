"""
1.创建
li = [1, 12, 'alex', 34]
列表中的元素可以是数字、字符串、列表、boolean....所有的都能放进去
相当于一个"集合"，内部可以放置任何东西

2.取值
索引取值
print（li[2]）
切片取值，切片的结果也是一个列表
li[3: 5]
for 循环
for item in li:
    print(item)

3.修改（列表元素可以被修改）
li[index] = X
li[s: e] = [X, Y]

4.删除
del li[index]  :删除某个元素
li.pop()  默认删除最后一个元素

5. in操作
x in li-->true or false

6.字符串转换为列表
s = "hhuhdhfjsnfkj"
list(s)

列表转换为字符串（如果列表里面的元素都是字符串，可以直接用j字符串的join直接拼接，否则自己写for循环）
"".join(li)

7.增加
li.append() 在原来值最后追加
extend() 扩展原来的列表，参数是可迭代对象
8.清空
li.clear()
9.复制
new_li = li.copy()
10.计算某个元素出现的次数
li.count(x)

11.查找某个元素出现的位置，从前往后，只找一次
li.index(value)

12.插入元素
li.insert(index, value)

"""