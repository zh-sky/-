class Solution(object):
    def subsets(self, nums):
        """
        :type nums: List[int]
        :rtype: List[List[int]]
        """
        if not nums:
            return []
        res = [[]]
        for i in range(0, len(nums)):
            for j in range(0, len(res)):
                temp = res[j]
                temp.append(nums[i])
                res.append(temp)
        return res


if __name__ == "__main__":
    solution = Solution()
    solution.subsets([1, 2, 3])