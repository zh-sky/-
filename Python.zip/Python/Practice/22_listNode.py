

class Node(object):
    """节点"""
    def __init__(self, val):
        self.val = val
        self.next = None


class SingleLinkList(object):
    """单向循环链表"""
    def __init__(self, node=None):
        self.__head = node
        if node != None:
            node.next = node

    def is_empty(self):
        """链表是否为空"""
        return self.__head == None

    def length(self):
        """返回链表的长度"""
        cur = self.__head
        count = 0
        while cur is not None:
            count += 1
            cur = cur.next
        return count

    def travel(self):
        """遍历整个链表"""
        cur = self.__head
        while cur is not None:
            print(cur.val)
            cur = cur.next

    def add(self, item):
        """链表头部添加元素"""
        node = Node(item)
        node.next = self.__head
        self.__head = node

    def append(self, item):
        """链表尾部添加元素"""
        node = Node(item)
        if self.is_empty():
            self.__head = node
        else:
            cur = self.__head
            while cur.next != None:
                cur = cur.next
            cur.next = node

    def insert(self, pos, item):
        """指定位置插入元素
        :param pos (从0开始)
        """
        if pos < 0:
            pos = 0
        elif pos > self.length() - 1:
            pos = self.length() - 1
        node = Node(item)
        index = 0
        pre = self.__head
        while index < pos - 1:
            index += 1
            pre = pre.next
        node.next = pre.next
        pre.next = node

    def remove(self, item):
        """删除节点"""
        pre = None
        cur = self.__head
        while cur != None:
            if cur.val == item:
                if cur == self.__head:
                    self.__head.next = cur.next
                else:
                    pre.next = cur.next
                break
            else:
                pre = cur
                cur = cur.next

    def search(self, item):
        """查找节点"""
        cur = self.__head
        while cur != None:
            if cur.val == item:
                return True
            cur = cur.next
        return False


if __name__ == "__main__":
    sll = SingleLinkList()
    print(sll.is_empty())
    print(sll.length())

    sll.append(1)
    sll.add(2)
    sll.add(3)
    sll.insert(1, 8)
    # print(sll.length())
    sll.travel()