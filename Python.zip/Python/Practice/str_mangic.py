# test = 'alex'
# v = test.endswith("ex")
# v = test.startswith("ex")
# print(v)
# # 获取第一次出现的下标位置
# v = test.find("ex")
# print(v)
#
# test_one = "i am {name}, age {a}"
# print(test_one)
# format_test = test_one.format(name="alex", a="18")
# print(format_test)
#
# # 字符串中是否包含字母和数字
# test = "usaf8080"
# print(test.isalnum())

# 判断输入的是否是数字
# test = "二"
# v1 = test.isdigit()
# v2 = test.isnumeric()
# v3 = test.isdecimal()
# print(v1, v2, v3)

# 字符串中的每一个元素按照指定分隔符进行拼接 *****
# test = "起风了"
# print("_".join(test)
#
# test = "起风了 hah nishu0"
# v = test.split()
# print(v)

# 切片
# test = "那就是我啊"
# print(test[0:-1], len(test))

# 字符串做加法和修改的时候  都会重新生成一个字符串


# test = input("<<<<")
# for i in range(len(test)):
#     print(i, test[i])

# li = ["用户名", "密码", "邮箱"]
# word = ""
# res = []
# k = 0
# while k < 3:
#     word = input(li[k])
#     if word == "q" or word == "Q":
#         break
#     elif len(word) > 20:
#         word = word[:21]
#     res.append(word)
#     k += 1
#
# for i in range(len(res)):
#     print(li[i], ":", res[i])

# 可迭代对象  ==可以被for进行循环获取


# 字符串转换成列表  字符串是可迭代对象
s = "i am liliy"
new_s = list(s)
# print(new_s)

li = ["de", "efr", "huji", "123"]
r = str(li)
# print(r)

s = ""
for i in li:
    s = s + str(i)
# print(s)

# 列表里面只有字符串时  可以使用join方法
# print("".join(li))

# 参数
li.append("pararm")
# print(li)

# 清空列表 clear()
# 拷贝
# 浅拷贝
li_copy = li.copy()
# print(li_copy)
li_copy.append("haha")
# print(li)
# print(li_copy)
# # 计算元素出现的次数
# print(li.count("de"))
# 添加可迭代对象 扩展原列表
li.extend(["8989", 123])
# print(li)
# print(li_copy)

# 删除列表中的指定值，左边优先 pop()

# 字典的魔法
# dic = {
#     "k1": "v1"
# }
# 根据序列 创建字典，并指定统一的值
# v = dict.fromkeys(["123", "k1", "999"], [123, 345, 678])
# print(v)
# 根据key获取值

"""
可变不可变：
1.可变：列表、字典
2.不可变：字符串、数字、元祖

访问顺序：
1.直接访问：数字
2.顺序访问：字符串、元祖、列表
3.映射：字典

存放元素个数：
容器类型：元祖、列表、字典
原子类型：字符串、数字

"""

"""
集合：
1.不同元素组成
2.无序
3.元素是不可变类型（数字、字符串和元组）

求并集：
union |  集合1 union 集合2   集合1 | 集合2

求差集
"-"  集合1-集合2
"""

# 百分号字符串拼接
# print("i am %s my hobby is" % "lily")

# 风湿理论：函数即变量

# test = 'aLex'
# # 首字母大写
# print(test.capitalize())
# # 所有字符变小写
# print(test.casefold())
# # 在某个位置内，把字符串放在中间,"*"代表空白位置填充
# print(test.center(20, "*"))
# # 字符串中某个字符出现的个数
# print(test.count('o'))
# # 字符串是否以xx结尾，end是开区间
# print(test.endswith("x", 0, 3))
# # 目标字符串开始的位置，从前往后找
# print(test.find('ex'))
# # 格式化 括号里面只能是字母或数字
# print("i am {name}".format(name='alex'))
# print("i am {1}, age is {0}".format(18, "lily"))
# format_map = {'name': "tom", "age": 12}
# print("i am {name}, age is {age}".format(**format_map))
# # 可以做表格用  空格中的数字是断句用的
# s = 'hsfnjfhd\tfknsmnfd\tee'
# print(s.expandtabs(6))
#
# # 是否是字母
# test = 'asdf1'
# print(test.isalpha())

# 是否是数字
# test = '二'
# print(test.isdecimal())
# # 支持特殊的数字字符
# print(test.isdigit())
# # 支持中文数字字符
# print(test.isnumeric())
# # 判断是否都是小写
# print(test.islower())
# # 是否存在不可显示的字符
# print("huhunkk".isprintable())
# # 判断是否全部是空格
# test = ""
# print(test.isspace())

# 判断是否是标题，每个单词的首字母都大写
test = "return true If you are a girl"
print(test.istitle())
test = test.title()
print(test.istitle())

# 将字符串中的每一个元素按照制定分隔符进行
print("*".join("胡恢复到回房间恢复数据恢复精神"))

# 去除左右空白 \t \n 或者指定的字符
test = " alex "
print(test.lstrip())
print(test.rstrip())

