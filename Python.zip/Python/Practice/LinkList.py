class Node():
    def __init__(self, data=None):
        self.data = data  # 数据域
        self.next = None  # 指针域


class LinkList():
    def __init__(self):
        self.head = None

    # 生产链表，这里使用list来生成
    def create(self, data):
        self.head = Node(data[0])
        p = self.head
        for i in data[1:]:
            p.next = Node(i)
            p = p.next

    # 遍历显示
    def print(self):
        p = self.head
        while p is not None:
            print(p.data, end=" ")
            p = p.next
        print()

    # 荷兰国旗排序
    def link_sort(self, k):
        small = Node()
        equal = Node()
        big = Node()
        p = self.head
        while p is not None:
            if k.data < p.data:
                big = p
            elif k.data > p.data:
                small = p
            else:
                equal = p
            p = p.next
        p = self.head
        while p is not None:
            if small is not None and p.data < k.data and small != p:
                small.next = p
                small = small.next
            elif equal is not None and p.data == k.data and equal != p:
                equal.next = p
                equal = equal.next
            elif big is not None and p.data > k.data and big != p:
                big.next = p
                big = big.next
    # 判断链表是否有环，有环的话返回该环的第一个节点


"""
本题中单链表可能有环，也可能无环。给定两个单链表的头结点head1和head2
这两个链表可能相交，也可能不相交。请实现一个函数，如果两个链表相交，请返回相交的第一个节点；
如果不相交返回null即可。
要求：如果链表1的长度为N,链表2的长度为M，时间复杂度请达到O(N+M),
额外空间复杂度请达到O(1)
思路：
if 都没有环（怎么判断一个单链表有没有环）
    判断是否有环
    第一种解法：使用哈希表
    # 使用集合保存
    res_set = set()
    while head is not None:
        if head in res_set:
            return head
        res_set.add(head)
        head = head.next
    return None
    第二种解法：使用快慢指针
    slow = head
    quick = head
    while slow != quick:
        if slow.next == None || qucik.next.next == None:
            return None
        slow = slow.next
        quick = quick.next.next
    quick = head
    while slow != quick:
        slow = slow.next
        quick = quick.next
    return slow

if 一个有环 一个无环
if 两个都有环
"""

if __name__ == "__main__":
    L = LinkList()
    L.create([4, 2, 5, 7, 9, 10, 23])
    L.print()


