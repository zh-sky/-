"""
int 的功能
1.转换：字符串转换为数字
2.不同进制间的相互转换
"""
a = "123"
print(int('1010', 2))
print(int('12', 8))
print(int('a', 16))
print(bin(10))
print(oct(10))
print(hex(10))

