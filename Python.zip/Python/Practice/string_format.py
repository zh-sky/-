"""
字符串格式化--拼接
"""
# print("i am %s my hobby is study" % 'tom')
# print('i am %s my age is %s' % ('lily', [11, 13]))
# name = 'anglebaby'
# age = 38
# print('her name is %s and age is %d' % (name, age))

# 打印浮点数
tpl = 'percent %f' % 9.7878978998
print(tpl)

# 打印百分比
tpl = 'percent %.2f%%' % 9.7878978998
print(tpl)

# format 格式化
tpl = 'i am {}, age {}, like {}'.format('tom', 14, 'eat')
print(tpl)

tpl = 'i am {2}, age {0}, like {1}'.format('tom', 14, 'eat')
print(tpl)