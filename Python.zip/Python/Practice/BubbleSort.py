import random

"""
首先明确几个概念：
1.算法：直白的理解就是设计一个功能的流程
2.扩展：不同的人可以对同一个功能设计出不同的流程，那么我们怎么去评价不同算法的好与坏呢，这里引入时间复杂度和空间复杂度的概念
3.时间复杂度的概念：一个算法流程中，常数操作数量的指标，这个指标叫做
O,读作 "big o".具体为，如果常数操作数量的表达式中，只要高阶项，不要低阶项，
也不要高阶项系数之后，剩下的部分记为f(N),那么该算法的时间复杂度为O(f(N))
4.空间复杂度的概念：指的是额外空间，输入输出或者传递的参数都不算
"""

"""
冒泡排序：
原理：
取出第n个数和前面（n-1）个数分别进行比较，如果a[n]<a[m](0-(n-1)),则交换两个元素的位置，
这样循环第一遍的时候就把第一大的数字排到了最后一位
循环第二遍的时候把第二大的数字拍到了倒数第二位
以此类推。。。
循环完成后，数组中的元素就像气泡一样按照从小到大的顺序排列
时间复杂度：O(n2)  空间复杂度：O(1)
"""

# def bubble_sort(arr):
#     if len(arr) < 2 or arr is None:
#         return
#     for i in range(len(arr)-1, 0, -1):
#         for j in range(i):
#             if arr[j] > arr[i]:
#                 arr[j], arr[i] = arr[i], arr[j]
#
#
# # li = [9, 8, 12, 6, 3, 28, 10]
# li = [2, 1]
# bubble_sort(li)
# print(li)

"""
选择排序：第一次循环选出0-n中的最小值放在0位置
第二次循环选出1-n中的最小值放在1位置
第三次循环选出2-n中的最小值放在2位置
依次类推。。。
时间复杂度：O（n^2）
"""

# def select_sort(arr):
#     # 若该数组为空或长度小于2  返回
#     if arr is None or len(arr) < 2:
#         return
#     for i in range(len(arr)-1):  # 循环范围（0-（n-1））
#         for j in range(i+1, len(arr)):  # 循环范围（1-n）
#             if arr[i] > arr[j]:
#                 arr[i], arr[j] = arr[j], arr[i]
#
#
# li = [9, 8, 12, 6, 3, 28, 10]
# # li = [2, 1]
# select_sort(li)
# print(li)
"""
插入排序：向数组中插入数据，没插入一个数字都和前面的数字依次进行比较，若小于
前面的数字，则交换两者位置。类似于一副已经排好序的扑克牌，新拿到一张牌时的排序方法
时间复杂度O(n^2)(最差情况下)

"""

# def insert_sort(arr):
# #     if arr is None or len(arr) < 2:
# #         return
# #     for i in range(1, len(arr)):
# #         for j in range(i-1, -1, -1):
# #             if arr[j+1] < arr[j]:
# #                 arr[j+1], arr[j] = arr[j], arr[j+1]
# #
# #
# # li = [9, 8, 12, 6, 3, 28, 10]
# # # li = [2, 1]
# # insert_sort(li)
# # print(li)


# 三大排序
"""
归并排序：使用递归排序实现，注意递归的 base case
递归：不断进栈和出栈的过程
递归属于宏观设计  不要死扣细节呀
时间复杂度：O(nlogn)
计算归并排序的时候需要用到master公式
T(N) = aT(N/b)+O(N^d)

"""

# 利用归并排序找出一个数组中的最大值
# def merge_sort(arr, L, R):
#     if L == R:
#         return arr[L]
#     mid_index = int(L + (R - L) / 2)  # 防止溢出
#     left_max = int(merge_sort(arr, L, mid_index))
#     right_max = int(merge_sort(arr, mid_index + 1, R))
#     max_num = max(left_max, right_max)
#     return max_num
#
#
# li = [3, 7, 23, 9, 10]
# print(merge_sort(li, 0, len(li)-1))


# 使用归并排序对数组进行排序  和外排结合进行
# def merge(arr, L, mid, R):
#     result = []  # 接收排好序的数组
#     p1 = L
#     p2 = mid + 1
#     while p1 <= mid and p2 <= R:
#         if arr[p1] < arr[p2]:
#             result.append(arr[p1])
#             p1 += 1
#         else:
#             result.append(arr[p2])
#             p2 += 1
#
#     while p1 <= mid:
#         result.append(arr[p1])
#         p1 += 1
#     while p2 <= R:
#         result.append(arr[p2])
#         p2 += 1
#     for j in range(len(result)):
#         arr[L+j] = result[j]
#
#
# def sort_process(arr, L, R):
#     if L == R:
#         return arr[L]
#     mid = int(L+(R-L)/2)
#     sort_process(arr, L, mid)
#     sort_process(arr, mid + 1, R)
#     merge(arr, L, mid, R)
#
#
# li = [3, 7, 23, 9, 10]
# sort_process(li, 0, len(li)-1)
# print(li)


# 利用归并排序求解
# 一个数组，求每一个数左边比它小的数字之和
# 例：4 1 3 5 0 6
# merge的过程中产生小合

# def merge(arr, l, m, r):
#     result = []
#     i = 0
#     p1 = l
#     p2 = m + 1
#     res = 0
#     while p1 <= m and p2 <= r:
#         if arr[p1] < arr[p2]:
#             res += (r-p2+1)*arr[p1]
#             result.append(arr[p1])
#             i += 1
#             p1 += 1
#         else:
#             result.append(arr[p2])
#             p2 += 1
#             i += 1
#     while p1 <= m:
#         result.append(arr[p1])
#         p1 += 1
#         i += 1
#     while p2 <= r:
#         result.append(arr[p2])
#         p2 += 1
#         i += 1
#     for j in range(len(result)):
#         arr[l + j] = result[j]
#     return res
#
#
# def merge_sort(arr, L, R):
#     if L == R:
#         return 0
#     mid = int(L+(R-L)/2)
#     return merge_sort(arr, L, mid) + merge_sort(arr, mid+1, R) + merge(arr, L, mid, R)
#
#
# print(merge_sort([4, 1, 3, 5, 0, 6], 0, 5))

#
"""
快速排序
1.找出数组中最后一个数字，根据该数字将数组划分为两部分（小于等于/大于）
2.小于区的初始位置在0位置前面
3.对数组进行循环遍历，若当前数字比最后一个数字小，则当前数字和小于区的下一位数字进行交换，小于区扩一个位置
4.空间复杂度O(logn)
"""

# 简单快排
# def partition1(arr, L, R):
#     p = arr[R]
#     less = L - 1  # 小于等于区的右边界
#     for i in range(R+1):
#         if arr[i] <= p:
#             arr[i], arr[less + 1] = arr[less + 1], arr[i]
#             less += 1
#
#
# # 荷兰国旗问题  小于  等于  大于  分成三部分
# def partition2(arr, L, R):
#     less = L - 1
#     more = R
#     while L < more:
#         if arr[L] < arr[R]:
#             arr[less+1], arr[L] = arr[L], arr[less+1]
#             L += 1
#             less += 1
#         elif arr[L] > arr[R]:
#             arr[L], arr[more - 1] = arr[more - 1], arr[L]
#             more -= 1
#         else:
#             L += 1
#     arr[more], arr[R] = arr[R], arr[more]
#     return [less + 1, more]


# li = [3, 2, 4, 5, 7, 6]
# li = [3, 2, 4, 5, 7, 6, 4]
# # partition1(li, 0, len(li)-1)
# partition2(li, 0, len(li) - 1)
# print(li)


# 随机快速排序
# 时间复杂度的好坏和划分的位置有关
# def quick_sort(arr, L, R):
#     if L < R:
#         random_num = arr(L + random.randint(0, (R-L+1)))
#         random_num, arr[R] = arr[R], random_num
#         res = partition2(arr, L, R)
#         quick_sort(arr, L, res[0]-1)
#         quick_sort(arr, res[1]+1, R)

"""
堆排序：
每次循环都生成一个堆，然后把堆顶和数组的最后一位交换，数组的有效长度减一

"""


# 生成大根堆的过程& 排序的过程   递归实现
# def heap_sort(arr, size):
#     if size < 1:
#         return
#     for i in range(size, -1, -1):
#         parent_index = int((i - 1) / 2)
#         if arr[i] > arr[parent_index] and parent_index >= 0:
#             arr[i], arr[parent_index] = arr[parent_index], arr[i]
#     arr[0], arr[size] = arr[size], arr[0]
#     # 每循环一次，有效长度减1
#     size -= 1
#     heap_sort(arr, size)
#
#
# test = [3, 4, 1, 5, 2, 0, 6, 7, 10, 9]
# heap_sort(test, len(test) - 1)
# print(test)
#
# """
# 桶排序：
# 基于数据状况进行计算
# 额外空间复杂度N
# 时间复杂度N
# """
#
#
# def bucket_sort(arr):
#     if arr is None or len(arr) < 2:
#         return
#     max_num = arr[0]
#     for i in range(1, len(arr)):
#         if max_num < arr[i]:
#             max_num, arr[i] = arr[i], max_num
#     # 初始化一个和原先数组长度一样的新数组
#     bucket_arr = [0] * (max_num + 1)
#     for i in range(len(arr)):
#         bucket_arr[arr[i]] += 1
#     i = 0
#     for j in range(len(bucket_arr)):
#         while bucket_arr[j] > 0:
#             arr[i] = j
#             j -= 1
#             i += 1
#
#
# # 应用情况  一个范围内的无序数字，排序后，求相邻两个数之间差值的最大值，时间复杂度控制在O(N)内
# def bucket(num, len, min_num, max_num):
#     return int((num - min_num) * (len / (max_num - min_num)))
#
#
# def max_gap(arr):
#     if arr is None or len(arr) < 2:
#         return
#     min_num = min(arr)
#     max_num = max(arr)
#     if min_num == max_num:
#         return 0
#     has_num = [False] * (len(arr) + 1)
#     maxs = [0] * (len(arr) + 1)
#     mins = [0] * (len(arr) + 1)
#     bid = 0
#     for i in range(len(arr)):
#         bid = bucket(arr[i], len(arr), min_num, max_num)
#         if has_num[bid]:
#             if maxs[bid] < arr[i]:
#                 maxs[bid] = arr[i]
#             elif mins[bid] > arr[i]:
#                 mins[bid] = arr[i]
#         has_num[bid] = True
#     last_max = maxs[0]
#     res = 0
#     for i in range(1, len(arr) + 1):
#         if has_num[i]:
#             if res < mins[i] - last_max:
#                 res = mins[i] - last_max
#     return res
#
#
# """
# 算法第三章：
# 1.用数组结构实现大小固定的队列和栈
# """
#
# # 栈
# def simulate_pop(arr, index, obj):
#     if index == len(arr):
#         print("栈满了")
#     arr[index] = obj
#     index += 1
#
#
# def simulate_push(arr, index):
#     if index == 0:
#         print("栈空了")
#     return arr[index - 1]
#
#
# # 队列
# def queue_pop(arr, size, start):
#     if size == 0:
#         print("队列已经空了")
#     size -= 1
#     tmp = start
#     if size-1 == start:
#         start = 0
#     else:
#         start += 1
#     return arr[tmp]
#
#
# def queue_push():
#     pass

# 转圈打印矩阵
"""
从宏观上来考虑：转圈一层一层转
1  2  3  4
5  6  7  8
9 10 11 12
13 14 15 16
"""


def print_edge(arr, row1, col1, row2, col2):
    if row1 == row2:
        for i in range(col2+1):
            print(arr[row1][i])
    elif col1 == col2:
        for i in range(row2+1):
            print(arr[i][col1])
    else:
        curC = col1
        curR = row1
        while curC != col2:
            print(arr[row1][curC])
            curC += 1
        while curR != row2:
            print(arr[curR][col2])
            curR += 1
        while curC != col1:
            print(arr[row2][curC])
            curC -= 1
        while curR != row1:
            print(arr[curR][col1])
            curR -= 1


# 打印Z字形矩阵
# 可以实现右上方向左上方  反之亦可
def print_level(arr, row1, col1, row2, col2, fromUp):
    if fromUp:
        while row1 <= row2:
            print(arr[row1][col1])
            row1 += 1
            col1 -= 1
    else:
        while row2 != row1 - 1:
            print(arr[row2][col2])
            row2 -= 1
            col2 += 1


def print_matrix_zigzag(arr):
    row1, row2, col1, col2 = 0, 0, 0, 0
    endR = len(arr) -1
    endC = len(arr[0]) - 1
    fromUp = False
    while row1 != endR + 1:
        print_level(arr, row1, col1, row2, col2, fromUp)
        if col1 == endC:
            row1 += 1
        else:
            col1 += 1
        if row2 == endR:
            col2 += 1
        else:
            row2 += 1
        fromUp = not fromUp


# 在行列都排好序的矩阵中找数
"""
给定一个有N*M的整型矩阵matrix和一个整数K，matrix的每一行和每一列都是排好序的。实现一个
函数，判断k是否在matrix中
"""


def find_number(arr, k):
    row1 = 0
    col1 = len(arr[0]) - 1
    while arr[row1][col1] > k:
        col1 -= 1
    if arr[row1][col1] == k:
        return True
    else:
        while row1 < len(arr) and col1 > -1:
            row1 += 1
            if arr[row1][col1] == k:
                return True
            if arr[row1][col1] > k:
                col1 -= 1
    return False

"""
对链表进行荷兰国旗排序
"""


li = [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [14, 15, 16, 17]]
row1 = 0
col1 = 0
row2 = len(li)-1
col2 = len(li[0])-1
# while row1 <= row2 and col1 <= col2:
#     print_edge(li, row1, col1, row2, col2)
#     row1 += 1
#     col1 += 1
#     row2 -= 1
#     col2 -= 1
print_matrix_zigzag(li)
