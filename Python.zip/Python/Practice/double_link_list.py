class Node(object):
    """结点"""
    def __init__(self, item):
        self.val = item
        self.prev = None
        self.next = None


class DoubleLinkList(object):
    """双向链表"""
    def __init__(self, node=None):
        self.__head = node

    def is_empty(self):
        if self.__head is None:
            return True
        return False

    def length(self):
        if self.is_empty():
            return 0
        cur = self.__head
        count = 0
        if cur is not None:
            count += 1
            cur = cur.next
        return count

    def add(self, item):
        node = Node(item)
        node.next = self.__head
        self.__head = node
        node.next.prev = node

    def remove(self, item):
        """删除节点"""
        cur = self.__head
        while cur is not None:
            if cur.val == item:
                if cur == self.__head:
                    cur.prev.next = cur.next
                    # 链表只有一个节点的情况
                    if cur.next:
                        cur.next.prev = None
                else:
                    cur.prev.next = cur.next
                    cur.next.prev = cur.prev
                    break
            else:
                cur = cur.next