from page import BasePage


class LoginPage(BasePage.BasePage):

    def __init__(self, section):
        super().__init__()
        self.section = section

    def get_account(self, account):
        return self.get_element(self.section, account)

    def get_password(self, password):
        return self.get_element(self.section, password)

    def get_login_btn(self, login_btn):
        return self.get_element(self.section, login_btn)

    def print_name(self):
        print("hhhh")


if __name__ == "__main__":
    """是否含有某个属性 属性包括：数据属性和函数属性"""
    print(hasattr(LoginPage, "__init__"))
    fun = getattr(LoginPage, "print_name")
    fun()