from util.read_ini import ReadIni
"""
这是page的基类，用来封装一些公告的基础方法
"""


class BasePage:
    def __init__(self):
        self.data = ReadIni()

    def get_element(self, section, key):
        return self.data.get_element(section, key)

