format_dic = {
    'ymd': '{0.year}{0.mon}{0.day}',
    'm-d-y': '{0.mon}-{0.day}-{0.year}',
    'y:m:d': '{0.year}:{0.mon}:{0.day}'
}


class Date:
    def __init__(self, year, mon, day):
        self.year = year
        self.mon = mon
        self.day = day

    def __format__(self, format_spec):
        print('my format')
        if not format_spec:
            format_spec = 'ymd'
        return format_dic[format_spec].format(self)


d1 = Date(2019, '08', '05')
# format(d1)  #d1.__format__
print(format(d1, 'y:m:d'))
