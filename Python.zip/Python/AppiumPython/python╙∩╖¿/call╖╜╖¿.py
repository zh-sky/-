class Foo:
    def __call__(self, *args, **kwargs):
        print('Foo callable')

f1 = Foo()
# f1()  执行的是Foo下的__call__方法