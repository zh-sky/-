"""python咩有类型检测功能"""


class Typed:
    def __init__(self, key, expected_type):
        self.key = key
        self.expected_type = expected_type

    def __get__(self, instance, owner):
        print('get method')
        print('instance arg [%s]' % instance)
        print('owner arg [%s]' % owner)
        return instance.__dict__[self.key]

    def __set__(self, instance, value):
        print('set method')
        print('instance arg [%s]' % instance)
        print('value arg [%s]' % value)
        if not isinstance(value, self.expected_type):
            raise TypeError('%s 传入的类型不是 %s' % (self.key, self.expected_type))
        instance.__dict__[self.key] = value

    def __delete__(self, instance):
        print('delete method')
        print('instance arg [%s]' % instance)
        instance.__dict__.pop(self.key)


class People:
    name = Typed('name', str)
    age = Typed('age', int)

    def __init__(self, name, age, salary):
        self.name = name
        self.age = age
        self.salary = salary


p1 = People('tom', 'tom', 11000)
# print(p1.__dict__)

# print(p1.name)
# print(p1.__dict__)
