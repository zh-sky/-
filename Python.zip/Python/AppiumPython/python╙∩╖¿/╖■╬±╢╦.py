"""
backLog:半连接池 对应到Python程序的listen这步。防止SYN洪水攻击的一个方法就是增大半链接池
"""
# import socket

# phone = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  #买手机
# phone.bind(('127.0.0.1', 8000))  #ip地址+端口   插卡
# phone.listen(5)  #每次可以挂几个服务  开机   backlog的大小
#
# conn, addr = phone.accept()  #拿到一个电话链接和对方的手机号  在建立3次握手
# msg = conn.recv(1024) #收消息
# print('客户端发来的消息是：', msg)
#
# conn.send(msg.upper()) #发消息　
#
# conn.close()
# phone.close()

from socket import *   # *代表导入socket下所有的方法
import subprocess
ip_port = ('127.0.0.1', 8000)
back_log = 5
buffer_size = 1024

tcp_server = socket(AF_INET, SOCK_STREAM)
tcp_server.bind(ip_port)
tcp_server.listen(back_log)
while True:
    conn, addr = tcp_server.accept()
    print('双向链接是', conn)
    print('客户端的地址是', addr)

    while True:
        try:
            msg = conn.recv(buffer_size)
            if not msg: break  #解决客户端输入quit后造成的死循环问题
            cmd = msg.decode('utf-8')
            print('客户端发来的消息是', cmd)
            res = subprocess.Popen(cmd, shell=True,
                                       stdout=subprocess.PIPE,
                                       stdin=subprocess.PIPE,
                                       stderr=subprocess.PIPE)   #定向到不同的管道里
            err = res.stderr.read()
            if err:
                cmd_res = err
            else:
                cmd_res = res.stdout.read()

            conn.send(cmd_res)
        except Exception as e:
            break

    conn.close()

tcp_server.close()