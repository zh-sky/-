# import socket
#
# phone = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# phone.connect(('127.0.0.1', 8000)) #拨通电话
# phone.send('hello'.encode('utf-8'))
# data = phone.recv(1024)
# print('服务端发来的消息是：', data)


"""
backLog:半连接池 对应到Python程序的listen这步。防止SYN洪水攻击的一个方法就是增大半链接池
"""
# import socket

# phone = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  #买手机
# phone.bind(('127.0.0.1', 8000))  #ip地址+端口   插卡
# phone.listen(5)  #每次可以挂几个服务  开机   backlog的大小
#
# conn, addr = phone.accept()  #拿到一个电话链接和对方的手机号  在建立3次握手
# msg = conn.recv(1024) #收消息
# print('客户端发来的消息是：', msg)
#
# conn.send(msg.upper()) #发消息　
#
# conn.close()
# phone.close()

from socket import *   # *代表导入socket下所有的方法
ip_port = ('127.0.0.1', 8000)
buffer_size = 1024

tcp_client = socket(AF_INET, SOCK_STREAM)
tcp_client.connect(ip_port)

while True:
    msg = input('请输入命令>>：').strip()
    if not msg:continue
    if msg == 'quit':break
    tcp_client.send(msg.encode('utf-8'))
    print('客户端已经发送消息')
    data = tcp_client.recv(buffer_size)
    print('收到服务端发来的消息', data.decode('gbk'))

tcp_client.close()
