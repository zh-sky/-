class Foo:
    __slots__ = ['name', 'age']  #只是定义了一堆key


f1 = Foo()
f1.name = 'tom'   #--->setattr--->f1.__dict['name'] = 'tom'
