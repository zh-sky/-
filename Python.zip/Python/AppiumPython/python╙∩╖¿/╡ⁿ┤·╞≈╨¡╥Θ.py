class Foo:
    def __init__(self, n):
        self.n = n

    def __iter__(self):
        return self

    def __next__(self):
        if self.n == 10:
            raise StopIteration
        self.n += 1
        return self.n

f1 = Foo(2)
print(f1.__next__())
print(f1.__next__())
print(f1.__next__())

for i in f1:  #iter(f1)-->f1.__iter__()
    print(i)