"""
udp协议实现ntp服务
"""
from socket import *

ip_port = ('127.0.0.1', 8080)
buffer_size = 1024

udp_client = socket(AF_INET, SOCK_DGRAM)

while True:
    msg = input('请输入：').strip()
    udp_client.sendto(msg.encode('utf-8'), ip_port)
    data, addr = udp_client.recvfrom(buffer_size)
    print('接收到服务端发过来的消息是：', data.decode('utf-8'))

