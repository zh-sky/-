l = ['a', 'b', 'c', 'd']
from functools import partial

# def test():
#     return l.pop()
#
#
# x = iter(test, 'b')  #执行这个函数  直到'b'为止
# print(x.__next__())
# print(x.__next__())
# # print(x.__next__())


def add(x):
    return x


func = partial(add, 2) #偏函数  可以固定函数的第一个参数
print(func())