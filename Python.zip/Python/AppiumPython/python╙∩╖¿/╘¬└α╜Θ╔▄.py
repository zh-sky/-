class Foo:
    pass

f1 = Foo()
print(type(f1))
print(type(Foo))


def __init__(self, name, age):
    self.name = name
    self.age = age


def test(self):
    pass


FFo = type('FFo', (object,), {'x': 1, '__init__': __init__, 'test': test})
print(FFo('TOM', 13).name)
