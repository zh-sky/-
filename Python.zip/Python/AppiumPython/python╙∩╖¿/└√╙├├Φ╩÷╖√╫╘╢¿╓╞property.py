class LazyProperty:
    def __init__(self, func):
        self.func = func

    def __get__(self, instance, owner):
        print('lazyproperty get')
        # 适用于类直接调用属性
        if instance is None:
            return self
        res = self.func(instance)
        setattr(instance, self.func.__name__, res)  #下次再调用时 不用再重复计算
        return res


class Room:
    def __init__(self, name, width, height):
        self.name = name
        self.width = width
        self.height = height

    @LazyProperty
    def area(self):
        return self.width * self.height


room = Room('wc', 10, 10)
print(room.area)
