"""
错误：
语法错误
异常：
程序运行时发生错误的信号
"""
# try:
#     age = input('>>: ')
#     int(age)
#
#     l = []
#     l[1]
# except ValueError as e:  #"ValueError"异常类只能用来处理指定的异常
#     print(e)
# except IndexError as e:
#     print(e)
# except KeyError as e:
#     print(e)


try:
    dic = {}
    dic['age']
except Exception as e: #万能异常
    print(e)