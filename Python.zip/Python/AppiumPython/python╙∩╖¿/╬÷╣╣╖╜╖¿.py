class Foo:
    def __init__(self, name):
        self.name = name

    def __del__(self):
        print('execute')


f1 = Foo('tom')
del f1  #删除实例 会触发del方法
# del f1.name #不会触发