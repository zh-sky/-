"""
在类的实例化之前，可以操作类的属性
"""


class Typed:
    def __init__(self, key, expected_type):
        self.key = key
        self.expected_type = expected_type

    def __get__(self, instance, owner):
        print('get method')
        print('instance arg [%s]' % instance)
        print('owner arg [%s]' % owner)
        return instance.__dict__[self.key]

    def __set__(self, instance, value):
        print('set method')
        print('instance arg [%s]' % instance)
        print('value arg [%s]' % value)
        if not isinstance(value, self.expected_type):
            raise TypeError('%s 传入的类型不是 %s' % (self.key, self.expected_type))
        instance.__dict__[self.key] = value

    def __delete__(self, instance):
        print('delete method')
        print('instance arg [%s]' % instance)
        instance.__dict__.pop(self.key)


def deco(**kwargs):
    print(kwargs)

    def wrapper(obj):
        for key, value in kwargs.items():
            setattr(obj, key, Typed(key, value))
        return obj
    return wrapper


@deco(name=str, age=int)
class People:
    # name = Typed('name', str)
    # age = Typed('age', int)
    #
    def __init__(self, name, age):
        self.name = name
        self.age = age