from socket import *   # *代表导入socket下所有的方法
import subprocess
import struct
ip_port = ('127.0.0.1', 8000)
back_log = 5
buffer_size = 1024

tcp_server = socket(AF_INET, SOCK_STREAM)
tcp_server.bind(ip_port)
tcp_server.listen(back_log)
while True:
    conn, addr = tcp_server.accept()
    print('双向链接是', conn)
    print('客户端的地址是', addr)

    while True:
        try:
            msg = conn.recv(buffer_size)
            if not msg: break  #解决客户端输入quit后造成的死循环问题
            cmd = msg.decode('utf-8')
            print('客户端发来的消息是', cmd)
            res = subprocess.Popen(cmd, shell=True,
                                       stdout=subprocess.PIPE,
                                       stdin=subprocess.PIPE,
                                       stderr=subprocess.PIPE)   #定向到不同的管道里
            err = res.stderr.read()
            if err:
                cmd_res = err
            else:
                cmd_res = res.stdout.read()

            lenth = len(cmd_res)
            data_length = struct.pack('i', lenth)
            conn.send(data_length)
            conn.send(cmd_res)

        except Exception as e:
            break

    conn.close()

tcp_server.close()