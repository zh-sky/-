from socket import *   # *代表导入socket下所有的方法
import struct
from functools import partial
ip_port = ('127.0.0.1', 8000)
buffer_size = 1024

tcp_client = socket(AF_INET, SOCK_STREAM)
tcp_client.connect(ip_port)

while True:
    msg = input('请输入命令>>：').strip()
    if not msg:continue
    if msg == 'quit':break
    tcp_client.send(msg.encode('utf-8'))
    print('客户端已经发送消息')

    #解决粘包
    length_tuple = struct.unpack('i', tcp_client.recv(4))
    length = length_tuple[0]

    # recv_size = 0
    # recv_msg = b''
    # while recv_size < length:
    #     recv_msg += tcp_client.recv(length)
    #     recv_size = len(recv_msg)

    recv_msg = ''.join(iter(partial(tcp_client.recv(buffer_size))), b'')
    print('收到服务端发来的消息', recv_msg.decode('gbk'))

tcp_client.close()
