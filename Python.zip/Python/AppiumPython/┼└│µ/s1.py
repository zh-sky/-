import requests
from bs4 import BeautifulSoup

reponse = requests.get(
    url='https://www.autohome.com.cn/news/'
)
reponse.encoding = reponse.apparent_encoding
# print(reponse.text)

soup = BeautifulSoup(reponse.text, features='html.parser')
target = soup.find(id = 'auto-channel-lazyload-article')
li_list = target.find_all('li')
for i in li_list:
    a = i.find('a')
    if a:
        print(a.attrs.get('href')) #超链接
        text = a.find('h3').text   #标题
        print(text)
        img_url = a.find('img').attrs.get('src') #图片链接
        print(img_url)
        img_reponse = requests.get(url=img_url) #拿到图片
        file_name = text + '.jpg'
        with open(file_name, 'wb') as f:
            f.write(img_reponse.content)