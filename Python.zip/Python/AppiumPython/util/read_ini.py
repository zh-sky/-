from configparser import ConfigParser
"""
读取配置文件的类
"""


class ReadIni:
    def __init__(self, driver, file_path=None):
        self.driver = driver
        self.data = ConfigParser()
        if not file_path:
            file_path = "../configuration_file/app_element.ini"
        self.data.read(file_path)

    def get_element(self, section, key):
        try:
            element = self.data.get(section, key)
        except:
            element = None
        # 对读出的元素定位进行分割
        if not element:
            by = element.split('>')[0]
            local = element.split('>')[1]
            if by == "id":
                return self.driver.find_element_by_id(local)
            elif by == "className":
                return self.driver.find_element_by_className(local)
            else:
                return self.driver.find_element_by_xpath(local)


if __name__ == "__main__":
    read = ReadIni()
    print(read.get_element('local', 'user'))

