from appium import webdriver
import time
"""
xpath定位 在移动端效率很低  web端效率较高
元素的className是一定会有的
"""

def get_driver():
    capabilities = {
        "platformName": "Android",
        "deviceName": "127.0.0.1:62001",
        "app": r"D:\imooc7.2.010102001android.apk",
        # "appWaitActivity": "com.imooc.component.imoocmain.splash.GuideActivity",
        "appWaitActivity": "com.imooc.component.imoocmain.index.MCMainActivity",
        "noReset": "True"
    }
    return webdriver.Remote("http://127.0.0.1:4723/wd/hub", capabilities)


driver = get_driver()
time.sleep(10)


def get_size():
    size = driver.get_window_size()
    return size['width'], size['height']


# 向左滑动
def swipe_left():
    x1 = get_size()[0]/10*9
    y1 = get_size()[1]/2
    x = get_size()[0]/10
    driver.swipe(x1, y1, x, y1)


# 向右滑动
def swipe_right():
    x1 = get_size()[0] / 10 * 9
    y1 = get_size()[1] / 2
    x = get_size()[0] / 10
    driver.swipe(x, y1, x1, y1)


def swipe_on(direction):
    if direction == 'left':
        swipe_left()
    elif direction == 'right':
        swipe_right()


def login():
    # 立即体验
    driver.find_element_by_class_name('android.widget.ImageView').click()
    time.sleep(2)
    # 点击“跳过”感兴趣方向
    driver.find_element_by_id('cn.com.open.mooc:id/tvSkip').click()
    time.sleep(2)
    # 我的  index定位
    # driver.find_elements_by_class_name('android.support.v7.app.ActionBar$Tab')[3].click()
    # 我的 层级定位
    driver.find_element_by_id('cn.com.open.mooc:id/tab_layout').find_elements_by_class_name('android.support.v7.app.ActionBar$Tab')[3].click()
    # 点击头像登录
    driver.find_element_by_id('cn.com.open.mooc:id/head_image').click()
    # 切换到登录页面
    driver.find_element_by_id('cn.com.open.mooc:id/right_text').click()
    # 输入账号
    driver.find_element_by_id('cn.com.open.mooc:id/accountEdit').send_keys('15721525908')
    # 输入账号  UIautomator定位
    driver.find_element_by_android_uiautomator('new UiSelector().text("手机号/邮箱")').clear()
    driver.find_element_by_android_uiautomator('new UiSelector().text("手机号/邮箱")').sendKeys('15721525908')

    # 输入密码
    # driver.find_element_by_id('cn.com.open.mooc:id/passwordEdit').send_keys('a123456zh')
    # 输入密码 xpath定位
    driver.find_element_by_xpath('//*[contains(@text,"密码")]').send_keys('a123456zh')
    # 点击登录
    driver.find_element_by_id('cn.com.open.mooc:id/login').click()


"""
原生和H5切换
"""
def get_webView():
    driver.find_element_by_android_uiautomator('new UiSelector().text("手记")').click()
    time.sleep(5)
    driver.find_element_by_android_uiautomator('new UiSelector().text("前后端分离 | 关于登录状态那些事")').click()
    time.sleep(3)
    windows = driver.contexts
    print(windows)

# swipe_on('left')
# swipe_on('left')
# swipe_on('right')
# swipe_on('left')
# login()
get_webView()