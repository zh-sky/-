class Foo:
    def __init__(self, name):
        self.name = name

    # 属性不存在的时候才会触发
    def __getattr__(self, item):
        print("重写getattr")

    # 定制设置属性的过程
    def __setattr__(self, key, value):
        # print("执行setattr")
        if type(value) is str:
            print("开始设置")
            self.__dict__[key] = value
        else:
            print("必须是字符串类型")

    def __delattr__(self, item):
        print("执行del")
        self.__dict__.pop(item)


class List(list):
    pass

# f1 = Foo('tom')
# # f1.age = 18
# # print(f1.name)
# # print(f1.age)
# del f1.name
# print(f1.name)

# l1 = List("HELLO WORLD")
# l2 = list('hello world')
# print(l1)
# print(l2)
# class Open:
#     def __init__(self, filename, mode = 'r', encoding = 'utf-8'):
#         self.filename = filename
#         self.mode = mode
#         self.encoding = encoding
#
#     def read(self):
#         pass
#
#     def write(self):
#         pass


def deco(obj):
    print('============')
    obj.x = 1
    obj.y = 2
    obj.z = 3
    return obj


@deco    #test = deco(test)
def test():
    print('test函数运行')


@deco   #Foo = deco(Foo)
class Foo:
    pass


if __name__ == "__main__":
    # f1 = Foo()
    # print(f1.__dict__)
    print(Foo.__dict__)